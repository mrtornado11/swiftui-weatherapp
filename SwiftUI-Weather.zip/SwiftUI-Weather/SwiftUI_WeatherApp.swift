//
//  SwiftUI_WeatherApp.swift
//  SwiftUI-Weather
//
//  Created by Armando Qose on 27.6.21.
//

import SwiftUI

@main
struct SwiftUI_WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
